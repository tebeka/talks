 /***************************************************************/
/***               interface to bltinmodule.c                  ***/
 /***************************************************************/

#ifndef _PSY_BLTINMODULE_H
#define _PSY_BLTINMODULE_H

/* empty */

#endif /* _PSY_BLTINMODULE_H */
